<?php $__env->startSection('admincontent'); ?>
<section class="bg0 p-t-23 p-b-130 mt-5">
    <div class="container">
        <div class="p-b-10">
            <h3 class="ltext-103 cl5">
                Dashboard
            </h3>
        </div>

        <div class="card">
            <div class="alert alert-success" role="alert">
                This is a success alert—check it out!
              </div>
            <div class="card-header">
                <h5>Dashboadr</h5>
            </div>
            <div class="card-body">
                <p>test</p>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/page/dashboard.blade.php ENDPATH**/ ?>