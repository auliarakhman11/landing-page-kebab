<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper py-3">
    <div class="container">
      <div class="row gy-3">

        <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <!-- Single Vendor -->
            <div class="single-vendor-wrap bg-img p-4 bg-overlay" style="background-image: url('<?php echo e(asset('suha')); ?>/img/bg-img/16.jpg')">
              <h6 class="vendor-title text-white"><?php echo e($o->nama); ?></h6>
              <div class="vendor-info">
                <p class="mb-1 text-white"><i class="ti ti-map-pin me-1"></i><?php echo e($o->alamat); ?></p>
                <div class="ratings lh-1"><i class="ti ti-star-filled"></i><i class="ti ti-star-filled"></i><i class="ti ti-star-filled"></i><i class="ti ti-star-filled"></i><i class="ti ti-star-filled"></i></div>
              </div>
              <?php if($o->map): ?>
              <a class="btn btn-primary btn-sm mt-3" target="_blank" href="<?php echo e($o->map); ?>">Google Maps<i class="ti ti-map-pin ms-1"></i></a>
              <?php endif; ?>
              <!-- Vendor Profile-->
              
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

        

      </div>
    </div>
  </div>
<!-- Map -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
            

        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/page/outlite.blade.php ENDPATH**/ ?>