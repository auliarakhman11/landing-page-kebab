<!doctype html>
<html lang="en">
  <head>
  	<title>Login Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="<?php echo e(asset('auth')); ?>/css/style.css">

	</head>
	<body>
        <div class="container d-flex justify-content-center mt-5">
            <div class="d-flex flex-column justify-content-between">
                <div class="card mt-3 p-5">
                    <div class="logo mb-3"><img width="50px;" src="<?php echo e(asset('auth')); ?>/images/kebabyasmin.jpeg"></div>
                    <div>
                        <p class="mb-1 text-warning">Start managing your</p>
                        <h4 class="mb-5 text-white">business!</h4>
                    </div> 
                </div>
                <div class="card two bg-white px-5 py-4 mb-3">
                    <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><input type="text" class="form-control" id="name" name="username" value="<?php echo e(old('username')); ?>" required><label class="form-control-placeholder" for="name">Username</label>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group"><input type="password" class="form-control" id="password" name="password" required><label class="form-control-placeholder" for="password">Password</label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <button type="submit" class="btn btn-warning btn-block btn-lg mt-1 mb-2"><span>Login<i class="fas fa-long-arrow-alt-right ml-2"></i></span></button>
                    </form>
                </div>
            </div>
        </div>

	<script src="<?php echo e(asset('auth')); ?>/js/jquery.min.js"></script>
  
  <script src="<?php echo e(asset('auth')); ?>/js/bootstrap.min.js"></script>
  

	</body>
</html><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/auth/login.blade.php ENDPATH**/ ?>