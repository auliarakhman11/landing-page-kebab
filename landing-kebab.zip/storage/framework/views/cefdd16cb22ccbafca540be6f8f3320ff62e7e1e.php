<style>
    .hamburger-inner, .hamburger-inner:after, .hamburger-inner:before {
    background-color: #fff;
}

.hov-cl1:hover {color: #FECD01;}

</style>
<header class="header-v2">
    <!-- Header desktop -->
    <div class="container-menu-desktop trans-03">
        <div class="wrap-menu-desktop">
            <nav class="limiter-menu-desktop p-l-45" style="background: #222222;">
                
                <!-- Logo desktop -->		
                <a href="#" class="logo">
                    <img src="<?php echo e(asset('auth')); ?>/images/kebabyasmin-removebg.png" alt="IMG-LOGO">
                </a>

                <!-- Menu desktop -->
                <div class="menu-desktop">
                    <ul class="main-menu">
                        <li>
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('about')); ?>">Tentang Kami</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('product')); ?>">Produk</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('outlite')); ?>">Outlite</a>
                        </li>

                        

                        

                        

                        

                        <li>
                            <a href="<?php echo e(route('contact')); ?>">Contact</a>
                        </li>
                    </ul>
                </div>	

                <!-- Icon header -->
                
                <div class="wrap-icon-header flex-w flex-r-m h-full">		
                    <?php if(Request::is(['product','transaksi','cart'])): ?>
                    <div class="flex-c-m h-full p-r-25 bor6">
                        <div class="icon-header-item cl0 hov-cl1 trans-04 p-lr-11 icon-header-noti js-show-cart count-cart" data-notify="0">
                            <i class="zmdi zmdi-shopping-cart"></i>
                        </div>
                    </div>
                    <?php endif; ?>

                    
                        
                    
                </div>
            </nav>
        </div>	
    </div>

    <!-- Header Mobile -->
    <div class="wrap-header-mobile fixed-top">
        <!-- Logo moblie -->		
        <div class="logo-mobile">
            <a href="/"><img src="<?php echo e(asset('auth')); ?>/images/kebabyasmin-removebg.png" alt="IMG-LOGO"></a>
        </div>

        
            <div class="logo-mobile">
                <h3 class="mtext-113 cl2 text-center" style="color: #FECD01">
                    Kebab Yasmin
                 </h3> <p class="text-light text-center">The Best Snack In The Night</p>
                 
            </div>
            
        
        
        

        <!-- Icon header -->
        <?php if(Request::is(['product','transaksi','cart'])): ?>
        <div class="wrap-icon-header flex-w flex-r-m h-full ">
            <div class="flex-c-m h-full">
                <div class="icon-header-item cl2 hov-cl1 trans-04  icon-header-noti js-show-cart count-cart" data-notify="0" >
                    <i class="zmdi zmdi-shopping-cart text-light"></i>
                </div>
            </div>
        </div>
        <?php endif; ?>
        

        <!-- Button show menu -->
        <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
            <span class="hamburger-box">
                <span class="hamburger-inner"></span>
            </span>
        </div>
    </div>


    <!-- Menu Mobile -->
    <div class="menu-mobile mt-5 fixed-top">
        <ul class="main-menu-m">
            <li>
                <a href="<?php echo e(route('home')); ?>">Home</a>
            </li>

            <li>
                <a href="<?php echo e(route('about')); ?>">Tentang Kami</a>
            </li>

            <li>
                <a href="<?php echo e(route('product')); ?>">Produk</a>
            </li>

            <li>
                <a href="<?php echo e(route('outlite')); ?>">Outlite</a>
            </li>

              
            <li>
                <a href="<?php echo e(route('contact')); ?>">Contact</a>
            </li>
        </ul>
    </div>

    <!-- Modal Search -->
    <div class="modal-search-header flex-c-m trans-04 js-hide-modal-search">
        <button class="flex-c-m btn-hide-modal-search trans-04">
            <i class="zmdi zmdi-close"></i>
        </button>

        <form class="container-search-header">
            <div class="wrap-search-header">
                <input class="plh0" type="text" name="search" placeholder="Search...">

                <button class="flex-c-m trans-04">
                    <i class="zmdi zmdi-search"></i>
                </button>
            </div>
        </form>
    </div>
</header><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/template/_header.blade.php ENDPATH**/ ?>