<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
	<div class="container">
		<div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
			<a href="<?php echo e(route('product')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
				Produk
				<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
			</a>

			<span class="stext-109 cl4">
				Transaksi
			</span>
		</div>
	</div>
		

	<!-- Shoping Cart -->
	<div class="bg0 p-t-75 p-b-85" >
		<div class="container">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>
			<div class="row">
				<div class="col-lg-12 col-xl-12 col-12 m-lr-auto m-b-50">
					<div class="m-l-25 m-r--38 m-lr-0-xl">
						<div class="wrap-table-shopping-cart">
							<table class="table-shopping-cart">
                                
                                <tr class="table_head">
                                    <th class="column-1">Tanggal</th>
                                    <th class="column-1">Jumlah<br>Produk</th>
                                    <th class="column-1">Total</th>
                                    <th class="column-1">Status</th>
                                </tr>
                                
                                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table_row js-show-modal1 modal-btn check-detail" inv="<?php echo e($i->no_invoice); ?>">
                                    <td class="column-1">
                                        <?php echo e(date('d M Y' , strtotime($i->tgl))); ?>

                                    </td>
                                    <td class="column-1"><?php echo e($i->jumlah); ?></td>
                                    <td class="column-1">Rp. <?php echo e(number_format($i->total,0)); ?></td>
                                    <td class="column-1"><?php echo e($i->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</table>
						</div>

						

					</div>
				</div>

                
			</div>
		</div>
	</div>

	<?php $__env->startSection('modal'); ?>
<form  method="post" id="form-cart">
<div class="wrap-modal1 js-modal1 p-t-60 p-b-20" id="modal-detail-produk">
    <div class="overlay-modal1 js-hide-modal1"></div>

    <div class="container">
        <div class="bg0 p-t-60 p-b-30 p-lr-15-lg how-pos3-parent">

            <div class="row">
                <div class="col-12">
					<div class="wrap-table-shopping-cart" id="form-detail">
						
					</div>
				</div>
            </div>
        </div>
    </div>
</div>
</form>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets')); ?>/plugins/sweetalert2/sweetalert2.min.js"></script>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

			$(document).on('click', '.check-detail', function() {
                var inv = $(this).attr("inv");
                
                $.ajax({
                url:"<?php echo e(route('detail')); ?>",
                method:"POST",
                data:{inv:inv},
                success:function(data){
					$('#form-detail').html(data);                            
                }

              });

            });

			// cekAuth();

			// function cekAuth(){
			// 	$.ajax({
			// 			url:"<?php echo e(route('checkAuth')); ?>",
			// 			method:"GET",
			// 			dataType:"json",
			// 			success:function(data){

			// 				if(data.status == 'not authenticated'){
			// 					const nomor = localStorage.getItem('nomor');
			// 					if(nomor){
			// 						$.ajax({
			// 							url:"<?php echo e(route('getDataUser')); ?>",
			// 							method:"POST",
			// 							data:{nomor:nomor},
			// 							success:function(data){
			// 								if(data.status == 'authenticated'){
			// 									$('#nama').val(data.nama);
			// 									$('#nomor').val(data.nomor);
			// 									$('#alamat').text(data.alamat);
			// 									$('#status').val(data.status); 
			// 								}else{
			// 									$('#status').val('not authenticated');
			// 								}                                   
			// 							}
			// 						});
			// 					}else{
			// 						$('#status').val('not authenticated');
			// 					}
			// 				}else{
			// 					$('#nama').val(data.nama);
			// 					$('#nomor').val(data.nomor);
			// 					$('#alamat').text(data.alamat);
			// 					$('#status').val(data.status);  
			// 				}					                                
			// 			}

			// 		});
			// }
			

            loadCart();
            function loadCart(){
                $.ajax({
                            url:"<?php echo e(route('loadCart')); ?>",
                            method:"GET",
                            success:function(data){
                                $('#cart').html(data);                
                            }
                        });
                
                $.ajax({
                        url:"<?php echo e(route('loadCount')); ?>",
                        method:"GET",
                        success:function(data){
                            $('.count-cart').attr('data-notify',data);                
                        }
                    });

                }


                function subtotal(){
                $.ajax({
                            url:"<?php echo e(route('subtotal')); ?>",
                            method:"GET",
                            success:function(data){
                                $('.subtotal').html('Rp. '+data);                
                            }
                        });

                }


        });
</script>
<?php $__env->stopPush(); ?>
    
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1644550/landing-kebab/resources/views/page/transaksi.blade.php ENDPATH**/ ?>