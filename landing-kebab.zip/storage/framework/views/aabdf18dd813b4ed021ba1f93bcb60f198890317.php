<!-- Footer -->
<footer class="bg3 p-t-75 p-b-32">
    <div class="container">
        <div class="p-t-40">
            <p class="stext-107 cl6 txt-center">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="<?php echo e(route('landing')); ?>" target="_blank">Kebab Yasmin</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->

            </p>
        </div>
    </div>
</footer><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/template/_footer_admin.blade.php ENDPATH**/ ?>