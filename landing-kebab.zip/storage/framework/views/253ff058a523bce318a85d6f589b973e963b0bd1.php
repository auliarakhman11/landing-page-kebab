<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <!-- Search Form-->
    <!-- Search Form-->
    
    <!-- Hero Wrapper -->
    <div class="hero-wrapper">
      <div class="container">
        <div class="pt-3">
          <!-- Hero Slides-->
          <div class="hero-slides owl-carousel">
            <!-- Single Hero Slide-->
            <div class="single-hero-slide" style="background-image: url('<?php echo e(asset('img')); ?>/bg1.png')">
              <div class="slide-content h-100 d-flex align-items-center">
                <div class="slide-text">
                  <h4 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-duration="1000ms">Kebab Yasmin</h4>
                  <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-duration="1000ms">Surganya Ngebab!</p>
                  
                </div>
              </div>
            </div>
            <!-- Single Hero Slide-->
            <div class="single-hero-slide" style="background-image: url('<?php echo e(asset('img')); ?>/bg2.png')">
              <div class="slide-content h-100 d-flex align-items-center">
                <div class="slide-text">
                  <h5 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-duration="1000ms">Action Crew</h5>
                  <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-duration="1000ms">Mengalahkan Pesanan Kalian Dengan Cepat</p>
                  
                </div>
              </div>
            </div>
            <!-- Single Hero Slide-->
            <div class="single-hero-slide" style="background-image: url('<?php echo e(asset('img')); ?>/kebab-final.gif')">
              <div class="slide-content h-100 d-flex align-items-center">
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Product Catagories -->
    
    <!-- Flash Sale Slide -->
    
    
    <!-- Top Products -->
    
    <div class="featured-products-wrapper py-3">
        <div class="container">
          <div class="section-heading d-flex align-items-center justify-content-between dir-rtl">
            <h6>Produk Terlaris</h6>
            
          </div>
          <div class="row g-2">
  
          <?php $__currentLoopData = $terlaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-4">
              <div class="card featured-product-card">
                <div class="card-body">
                  <!-- Badge--><span class="badge badge-warning custom-badge"><i class="ti ti-star-filled"></i></span>
                  <div class="product-thumbnail-side">
                    <!-- Thumbnail --><a class="product-thumbnail d-block" href="javascript:void(0)"><img src="https://admin.kebabyasmin.id/<?php echo e($t->foto); ?>" alt=""></a>
                  </div>
                  <div class="product-description">
                    <!-- Product Title --><a class="product-title d-block" href="javascript:void(0)"><?php echo e($t->nm_produk); ?></a>
                    <!-- Price -->
                    
                    <p class="sale-price"><?php echo e(number_format($t->harga,0)); ?></p>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            
  
          </div>
        </div>
      </div>

    <!-- CTA Area -->
    
    <!-- Weekly Best Sellers-->
    
    <!-- Discount Coupon Card-->
    

    <!-- Dark Mode -->
    <div class="container">
        <div class="dark-mode-wrapper mt-3 bg-img p-4 p-lg-5">
          <p class="text-white">You can change your display to a dark background using a dark mode.</p>
          <div class="form-check form-switch mb-0">
            <label class="form-check-label text-white h6 mb-0" for="darkSwitch">Switch to Dark Mode</label>
            <input class="form-check-input" id="darkSwitch" type="checkbox" role="switch">
          </div>
        </div>
      </div>

    <!-- Featured Products Wrapper-->

    <div class="top-products-area py-3">
        <div class="container">
          <div class="section-heading d-flex align-items-center justify-content-between dir-rtl">
            <h6>Semua Produk</h6>
            
          </div>
          <div class="row g-1 align-items-center rtl-flex-d-row-r">
              <div class="col-12">
                  <!-- Product Catagories Slide -->
                  <div class="product-catagories owl-carousel catagory-slides">
                      <a class="shadow-sm bg-warning boxselect" href="javascript:void(0)" kategori_id="all">All</a>
                      <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="shadow-sm bg-warning boxselect" href="javascript:void(0)" kategori_id="<?php echo e($k->id); ?>"><?php echo e($k->kategori); ?></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                  </div>
              </div>
              
            </div>
  
  
          <div class="search-form pt-3 rtl-flex-d-row-r">
          <form action="#" method="">
              <input id="search_field" class="form-control" type="text" placeholder="Search product">
              
              
          </form>
          <!-- Alternative Search Options -->
          
          </div>
  
  
            <div class="mb-3"></div>
          <div class="row g-2" id="demonames">
          
              <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-4 col-md-4 box all <?php echo e($p->kategori_id); ?>">
                  <div class="card product-card">
                    <div class="card-body">
                      
                      <!-- Thumbnail --><a class="product-thumbnail d-block" href="javascript:void(0)"><img class="mb-2" loading="lazy" src="https://admin.kebabyasmin.id/<?php echo e($p->foto); ?>" alt=""></a>
                      <!-- Product Title --><a class="product-title demoname" href="javascript:void(0)" style="font-size: 12px;"><?php echo e($p->nm_produk); ?></a>
                      <!-- Product Price -->
                      <p class="sale-price" style="font-size: 12px;">Rp.<?php echo e(number_format($p->harga,0)); ?></span></p>
                      
                      <!-- Rating -->
                      
                      
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            
  
          </div>
        </div>
      </div>

    
    
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
            
            $(document).on('click', '.boxselect', function(event) {
                $this = $(this);
                $('.box').hide();
                $('.' + $this.attr('kategori_id')).show();
                // console.log("showing " + $this.attr('kategori_id') + " boxes");
            });

            var btsearch = {
                init: function(search_field, searchable_elements, searchable_text_class) {
                $(search_field).keyup(function(e) {
                    e.preventDefault();
                    var query = $(this).val().toLowerCase();
                    if (query) {
                    // loop through all elements to find match
                    $.each($(searchable_elements), function() {
                        var title = $(this).find(searchable_text_class).text().toLowerCase();
                        if (title.indexOf(query) == -1) {
                        $(this).hide();
                        } else {
                        $(this).show();
                        }
                    });
                    } else {
                    // empty query so show everything
                    $(searchable_elements).show();
                    }
                });
                }
            }

            // INIT
            $(function() {

                btsearch.init('#search_field', '#demonames div', '.demoname');
            });


        });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/page/home.blade.php ENDPATH**/ ?>