<!-- Footer -->
<footer class="bg3 p-t-30 p-b-10">
    <div class="container">
        <div class="row justify-content-center">

            

            

            <div class="col-8 col-lg-3 p-b-20">
                <h4 class="stext-301 cl0 p-b-10">
                    Contact
                </h4>

                <p class="stext-107 cl7 size-201">
                    Jl. Kp. Melayu Darat, Melayu, Kec. Banjarmasin Tengah, Kota Banjarmasin, Kalimantan Selatan 70121
                </p>

                <div class="p-t-27">

                    <a href="https://www.instagram.com/kebabyasmin/" class="fs-18 cl7 hov-cl1 trans-04 m-r-16">
                        <i class="fa fa-instagram"></i> <span class="fs-10">@kebabyasmin</span>
                    </a>

                    <a href="https://wa.me/+6285849979335" class="fs-18 cl7 hov-cl1 trans-04 m-r-16">
                        <i class="fa fa-whatsapp"></i> <span class="fs-10">085849979335</span>
                    </a>
                </div>
            </div>

            
        </div>

        <div class="p-t-10">
            

            <p class="stext-107 cl6 txt-center">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="" target="_blank">Kebab Yasmin Official</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->

            </p>
        </div>
    </div>
</footer><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/template/_footer.blade.php ENDPATH**/ ?>