<?php $__env->startSection('content'); ?>

<section class="bg0 p-t-55 p-b-20 mt-4">
    <div class="container">

        

        <div class="row justify-content-center p-b-20">

            

            <div class="col-12 col-md-8">
                <h3 class="mtext-113 cl2 p-b-16 text-center">
                    <u>Tentang Kami</u>
                 </h3>

                 <p class="mtext-101 cl6 p-b-26 text-center">
                    Kebab Yasmin Adalah Salah Satu Kebab Yang Berasal Dari Kota Banjarmasin, Berdiri Sejak Tahun 2012, Outlet Kebab Yasmin Sudah Tersebar Diwilayah Profinsi Kalimantan Selatan Seperti Di Banjarmasin, Banjarbaru, Martapura, Rantau, Tanjung Dan InsyaAllah Akan Membuka Dikota-Kota Lain
                 </p>
            </div>
        </div>
        

        
        
        


    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
            $('.carousel').carousel({
                interval: 3000
                })

            // loadCart();
            // loadTableCart();
            // function loadCart(){
            //     $.ajax({
            //                 url:"<?php echo e(route('loadCart')); ?>",
            //                 method:"GET",
            //                 success:function(data){
            //                     $('#cart').html(data);                
            //                 }
            //             });
                
            //     $.ajax({
            //             url:"<?php echo e(route('loadCount')); ?>",
            //             method:"GET",
            //             success:function(data){
            //                 $('.count-cart').attr('data-notify',data);                
            //             }
            //         });

            //     }

            //     function loadTableCart(){
            //     $.ajax({
            //                 url:"<?php echo e(route('loadTableCart')); ?>",
            //                 method:"GET",
            //                 success:function(data){
            //                     $('#table-cart').html(data);                
            //                 }
            //             });
            //     }

        });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1644550/landing-kebab/resources/views/page/about.blade.php ENDPATH**/ ?>