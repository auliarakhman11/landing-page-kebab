<section class="section-slide">
    <div class="wrap-slick1 rs2-slick1">
        <div class="slick1">

            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item-slick1 bg-overlay1" style="background-image: url(http://127.0.0.1:8000/storage/<?php echo e($p->foto); ?>);" data-thumb="http://127.0.0.1:8000/storage/<?php echo e($p->foto); ?>" data-caption="Women’s Wear">
                <div class="container h-full">
                    <div class="flex-col-c-m h-full p-t-100 p-b-60 respon5">
                        <div class="layer-slick1 animated visible-false" data-appear="fadeInDown" data-delay="0">
                            <span class="ltext-202 txt-center cl0 respon2">
                                <?php echo e($p->caption1); ?>

                            </span>
                        </div>
                            
                        <div class="layer-slick1 animated visible-false" data-appear="fadeInUp" data-delay="800">
                            <h2 class="ltext-104 txt-center cl0 p-t-22 p-b-40 respon1">
                                <?php echo e($p->caption2); ?>

                            </h2>
                        </div>
                            
                        <div class="layer-slick1 animated visible-false" data-appear="zoomIn" data-delay="1600">
                            <a href="product.html" class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn2 p-lr-15 trans-04">
                                Shop Now
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

            

            

        </div>

        <div class="wrap-slick1-dots p-lr-10"></div>
    </div>
</section><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/component/slider.blade.php ENDPATH**/ ?>