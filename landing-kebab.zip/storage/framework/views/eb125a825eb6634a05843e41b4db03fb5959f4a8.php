<tr class="table_head">
    <th class="column-1">Product</th>
    <th class="column-2"></th>
    <th class="column-3">Price</th>
    <th class="column-4">Quantity</th>
    <th class="column-5">Total</th>
</tr>

<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="table_row">
    <td class="column-1">
        <div class="how-itemcart1">
            <img src="http://127.0.0.1:8000/<?php echo e($c->options->foto); ?>" alt="IMG">
        </div>
    </td>
    <td class="column-2"><?php echo e($c->name); ?></td>
    <td class="column-3">Rp. <?php echo e(number_format($c->price,0)); ?></td>
    <td class="column-4">
        <div class="wrap-num-product flex-w m-l-auto m-r-0">
            <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m min-qty" rowId="<?php echo e($c->rowId); ?>">
                <i class="fs-16 zmdi zmdi-minus"></i>
            </div>

            <input class="mtext-104 cl3 txt-center num-product" type="number" name="num-product1" value="<?php echo e($c->qty); ?>">

            <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m plus-qty" rowId="<?php echo e($c->rowId); ?>">
                <i class="fs-16 zmdi zmdi-plus"></i>
            </div>
        </div>
    </td>
    <td class="column-5">Rp. <?php echo e(number_format($c->qty * $c->price,0)); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/component/tablecart.blade.php ENDPATH**/ ?>