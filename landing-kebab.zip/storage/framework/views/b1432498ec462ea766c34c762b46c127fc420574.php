<?php $__env->startSection('content'); ?>

<section class="bg0 p-t-23 p-b-130 mt-3">
    <div class="container">
        <div class="p-b-10">
            <h3 class="ltext-103 cl5">
                Product Overview
            </h3>
        </div>

        <div class="flex-w flex-sb-m p-b-52">
            <div class="flex-w flex-l-m filter-tope-group m-tb-10">
                <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1" data-filter="*">
                    All Products
                </button>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".<?php echo e($k->kategori); ?>">
                    <?php echo e($k->kategori); ?>

                </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            
            
            <!-- Search product -->
            

            <!-- Filter -->
            
        </div>

        <div class="row isotope-grid">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item <?php echo e($p->kategori); ?>">
                <!-- Block2 -->
                <div class="block2">
                    
                        <div class="block2-pic hov-img0">
                        <img class="lazy" src="https://admin.kebabyasmin.id/<?php echo e($p->foto); ?>" alt="IMG-PRODUCT">

                        <a href="#" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1 modal-btn" detail="<?php echo e($p->id); ?>">
                            Quick View
                        </a>
                    </div>

                    <div class="block2-txt flex-w flex-t p-t-14">
                        <div class="block2-txt-child1 flex-col-l ">

                            <span class="stext-301 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                <b><?php echo e($p->nm_produk); ?></b>
                            </span>                  
                                

                            <span class="stext-301 cl3">
                                <b>Rp. <?php echo e(number_format($p->harga,0)); ?></b>
                            </span>
                        </div>

                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

            

        </div>

        <!-- Pagination -->
        

    </div>
</section>


<?php $__env->startSection('modal'); ?>
<form  method="post" id="form-cart">
<div class="wrap-modal1 js-modal1 p-t-60 p-b-20" id="modal-detail-produk">
    <div class="overlay-modal1 js-hide-modal1"></div>

    <div class="container">
        <div class="bg0 p-t-60 p-b-30 p-lr-15-lg how-pos3-parent">

            

            <div class="row">
                <div class="col-md-6 col-lg-7 p-b-30">
                    <div class="p-l-25 p-r-30 p-lr-0-lg">
                        <div class="wrap-slick3 flex-sb flex-w">
                            
                            <div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

                            

                            <img src="" width="100%;" alt="IMG-PRODUCT" id="foto-produk">

                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-5 p-b-30">
                    <div class="p-r-50 p-t-5 p-lr-0-lg">
                        <h4 class="mtext-105 cl2 js-name-detail p-b-14" id="nm-produk">
                            
                        </h4>

                        <span class="mtext-106 cl2" id="harga-produk">
                            
                        </span>

                        
                        
                            <!--  -->
                            
                            <div class="p-t-33">
                            

                            

                            <div class="flex-w flex-r-m p-b-10">
                                <div class="size-204 flex-w flex-m respon6-next">
                                    <input type="hidden" name="id_produk" id="id-produk"  value="">
                                    <div class="wrap-num-product flex-w m-r-20 m-tb-10">
                                        <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
                                            <i class="fs-16 zmdi zmdi-minus"></i>
                                        </div>
                                        
                                        
                                        <input class="mtext-104 cl3 txt-center num-product" type="number" id="qty-produk" name="qty" value="1">

                                        <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
                                            <i class="fs-16 zmdi zmdi-plus"></i>
                                        </div>
                                        
                                    </div>

                                    

                                    

                                    

                                    
                                
                                </div>
                            </div>	
                        </div>

                        <?php $__currentLoopData = $ketegori_varian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($kv->id == 1): ?>
                                        <div class="row">
                                            <div class="col-12 mb-2"><p><center><u><?php echo e($kv->kategori_varian); ?></u></center></p></div>
                                            <?php $__currentLoopData = $kv->getVarian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6">
                                                <div class="row">
                                                    
                                                    <div class="col-3"><input type="radio" id="saos<?php echo e($g->id); ?>" name="saos" value="<?php echo e($g->id); ?>" class="form-control">
                                                    </div>
                                                    <div class="col-9">
                                                        <label for="saos<?php echo e($g->id); ?>"><?php echo e($g->nm_varian); ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                        <?php else: ?>
                                        <br>

                                        <div class="row">
                                            <div class="col-12"><hr></div>
                                            <div class="col-12 mb-2"><p><center><u><?php echo e($kv->kategori_varian); ?></u></center></p></div>
                                            <?php $__currentLoopData = $kv->getVarian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6">
                                                <div class="row">
                                                    
                                                    <div class="col-3"><input type="checkbox" name="tambahan[]" id="tambahan<?php echo e($g->id); ?>" value="<?php echo e($g->id); ?>" class="form-control">
                                                    </div>
                                                    <div class="col-9">
                                                        <label for="tambahan<?php echo e($g->id); ?>"><?php echo e($g->nm_varian); ?> (Rp. <?php echo e(number_format($g->harga,0)); ?>)</label>
                                                    </div>
                                                </div>
                                                    
                                                
                                            
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="row mb-2">
                                        <div class="col-12"><hr></div>
                                        
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <label for="floatingTextarea">Catatan*</label>
                                                <textarea class="form-control" name="ket"></textarea>
                                                
                                              </div>
                                        </div>
                                    </div>

                        <button class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 js-addcart-detail" id="add-cart" type="submit">
                            Add to cart
                        </button>
                        <!--  -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</form>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js"></script>
<script>
    
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            $(function() {
                $('.lazy').Lazy();
            });

            loadCart();
            function loadCart(){
                $.ajax({
                            url:"<?php echo e(route('loadCart')); ?>",
                            method:"GET",
                            success:function(data){
                                $('#cart').html(data);                
                            }
                        });
                
                $.ajax({
                        url:"<?php echo e(route('loadCount')); ?>",
                        method:"GET",
                        success:function(data){
                            $('.count-cart').attr('data-notify',data);                
                        }
                    });

                }

            $(document).on('click', '.modal-btn', function() {
                $('#form-cart').trigger("reset");
                var id_produk = $(this).attr("detail");
                var foto_location = 'https://admin.kebabyasmin.id/';

                $('#modal-detail-produk').show();

                $.ajax({
                url:"<?php echo e(route('getProduk')); ?>",
                method:"POST",
                data:{id_produk:id_produk},
                dataType:"json",
                success:function(data){
                  
                  // alert(data.biaya);
                //   $('#cancel').modal('show');
                  var foto = foto_location+data.foto;
                  $('#nm-produk').text(data.nm_produk);
                  $('#foto-produk').attr('src',foto);
                  $('.data-thumb-produk').attr('data-thumb',foto);
                  $('#id-produk').val(data.id_produk);
                  $('#harga-produk').text('Rp. '+data.harga);
                                    
                }

              });

            });

        $(document).on('submit', '#form-cart', function(event){  
           event.preventDefault();
           $("#add-cart").attr("disabled", true);
           $("#add-cart").text("loading...");
              $.ajax({  
                     url:"<?php echo e(route('addCart')); ?>",  
                     method:'POST',  
                     data:new FormData(this),  
                     contentType:false,  
                     processData:false,  
                     success:function(data)  
                     {  
                      if(data == 'success'){
                        swal(data, "berhasil masuk keranjang!", "success");
                        $('#modal-detail-produk').fadeOut();
                        $('#qty-produk').val('1');
                        loadCart();
                        $("#add-cart").removeAttr("disabled");
                        $("#add-cart").text("Add to cart");

                        $('#form-cart').trigger("reset");
                      }else if(data == 'qty'){
                        swal('Ada Masakah', "Jumlah tidak boleh kurang dari 1", "error");
                        $("#add-cart").removeAttr("disabled");
                        $("#add-cart").text("Add to cart");
                      }else if(data == 'saos'){
                        swal('Ada Masakah', "Pilihan saos tidak boleh kosong!", "error");
                        $("#add-cart").removeAttr("disabled");
                        $("#add-cart").text("Add to cart");
                      }else{
                        swal('Ada', "Masalah !", "error");
                        $("#add-cart").removeAttr("disabled");
                        $("#add-cart").text("Add to cart");
                        
                      }
                     }, error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                        }
                });        
            });


        });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1644550/landing-kebab/resources/views/page/landing.blade.php ENDPATH**/ ?>