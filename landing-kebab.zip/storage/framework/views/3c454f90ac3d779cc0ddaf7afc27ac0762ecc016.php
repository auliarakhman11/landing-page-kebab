<table class="table-shopping-cart">
   
        <tr class="table_head">
            <th class="text-center column-1">Produk</th>						<th class="text-center column-1"></th>	
            <th class="text-center column-1">Qty</th>
            <th class="text-center column-1">Harga</th>
            <th class="text-center column-1">Subtotal</th>
        </tr>
        <?php
            $total = 0;
        ?>
        <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $total += $p->total;
        ?>
        <tr class="table_row">
            <td class="text-center column-1"><?php echo e($p->nm_produk); ?></td>
            <td class="text-center column-1"><img width="50px;" src="http://127.0.0.1:8000/storage/<?php echo e($p->foto); ?>" alt="IMG"></td>
            <td class="text-center column-1"><?php echo e($p->qty); ?></td>
            <td class="text-center column-1"><?php echo e(number_format($p->harga_jual,0)); ?></td>
            <td class="text-center column-1"><?php echo e(number_format($p->total,0)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="4" class="text-center"><strong>Total</strong></td>
            <td class="text-center"><strong><?php echo e(number_format($total,0)); ?></strong></td>
        </tr>
        
    </tbody>
</table><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/component/detail.blade.php ENDPATH**/ ?>