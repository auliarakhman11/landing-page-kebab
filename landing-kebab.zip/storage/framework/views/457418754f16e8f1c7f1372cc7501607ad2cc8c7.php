<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover, shrink-to-fit=no">
    <meta name="description" content="Suha - Multipurpose Ecommerce Mobile HTML Template">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#625AFA">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <!-- The above tags *must* come first in the head, any other head content must come *after* these tags -->
    <!-- Title -->
    <title><?php echo e($title); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&amp;display=swap" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('img')); ?>/kebab-yasmin-putih.png">
    <!-- Apple Touch Icon -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('img')); ?>/kebab-yasmin.png">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('img')); ?>/kebab-yasmin.png">
    <link rel="apple-touch-icon" sizes="167x167" href="<?php echo e(asset('img')); ?>/kebab-yasmin.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img')); ?>/kebab-yasmin.png">
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/tabler-icons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/animate.css">
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/css/nice-select.css">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('suha')); ?>/style.css">
    <!-- Web App Manifest -->
    <link rel="manifest" href="<?php echo e(asset('suha')); ?>/manifest.json">
  </head>
  <body>
    <!-- Preloader-->
    <div class="preloader" id="preloader">
      <div class="spinner-grow text-secondary" role="status">
        <div class="sr-only"></div>
      </div>
    </div>
    <!-- Header Area -->
    
	<?php echo $__env->make('template._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('template._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- PWA Install Alert -->
    

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Internet Connection Status-->
    <div class="internet-connection-status" id="internetStatus"></div>
    <!-- Footer Nav-->
    <?php echo $__env->make('template._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- All JavaScript Files-->
    
    <script src="<?php echo e(asset('suha')); ?>/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/waypoints.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.counterup.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.countdown.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.passwordstrength.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/jquery.nice-select.min.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/theme-switching.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/no-internet.js"></script>
    <script src="<?php echo e(asset('suha')); ?>/js/active.js"></script>
    

    <script>
      $(document).ready(function () {

        $(document).on('click', '#darkSwitch', function(event) {
          let theme = localStorage.getItem("theme");
          if (theme == 'light') {
            let url = "<?php echo e(asset('img')); ?>/kebab-yasmin-putih.png";
            $('#logo_web').attr('src',url);
          }else{
            let url = "<?php echo e(asset('img')); ?>/kebab-yasmin.png";
            $('#logo_web').attr('src',url);
          }
        });
        
        function checkTheme() {
          let theme = localStorage.getItem("theme");
          if (theme == 'dark') {
            let url = "<?php echo e(asset('img')); ?>/kebab-yasmin-putih.png";
            $('#logo_web').attr('src',url);
          }else{
            let url = "<?php echo e(asset('img')); ?>/kebab-yasmin.png";
            $('#logo_web').attr('src',url);
          }
        }

        checkTheme();

        

      });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
  </body>
</html><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/template/master.blade.php ENDPATH**/ ?>