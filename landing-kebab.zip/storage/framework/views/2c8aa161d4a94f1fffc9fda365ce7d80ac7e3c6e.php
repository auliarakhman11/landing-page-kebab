<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-center d-flex rtl-flex-d-row-r">
      <!-- Logo Wrapper -->
      <div class="logo-wrapper"><a href="<?php echo e(route('home')); ?>"><img id="logo_web" src="<?php echo e(asset('img')); ?>/kebab-yasmin.png" alt="" style="height: 55px;"></a></div>
      
    </div>
  </div><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/template/_header.blade.php ENDPATH**/ ?>