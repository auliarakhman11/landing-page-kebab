<div class="footer-nav-area" id="footerNav">
    <div class="suha-footer-nav">
      <ul class="h-100 d-flex align-items-center justify-content-between ps-0 d-flex rtl-flex-d-row-r">

        <li><a href="<?php echo e(route('outlet')); ?>"><i class="ti ti-building-store"></i>Outlet</a></li>
        <li><a href="<?php echo e(route('home')); ?>"><i class="ti ti-home"></i>Home</a></li>
        <li><a href="<?php echo e(route('about')); ?>"><i class="ti ti-info-hexagon"></i>About Us</a></li>

        
      </ul>
    </div>
</div><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/template/_footer.blade.php ENDPATH**/ ?>