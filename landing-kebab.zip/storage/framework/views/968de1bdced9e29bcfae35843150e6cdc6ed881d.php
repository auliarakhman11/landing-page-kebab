<div class="header-cart-content flex-w js-pscroll">
    <ul class="header-cart-wrapitem w-full">
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="header-cart-item flex-w flex-t m-b-12">
            <div class="header-cart-item-img">
                <img src="https://admin.kebabyasmin.com/<?php echo e($c->options->foto); ?>" alt="IMG">
            </div>

            <div class="header-cart-item-txt p-t-8">
                <a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">
                    <?php echo e($c->name); ?> 
                </a>

                <span class="header-cart-item-info">
                    <?php echo e($c->qty); ?> x Rp.<?php echo e($c->price); ?>

                </span>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </ul>
    
    <div class="w-full">
        <div class="header-cart-total w-full p-tb-40">
            Total: Rp.<?php echo e($total); ?>

        </div>

        <div class="header-cart-buttons flex-w w-full">
            

            <a href="<?php echo e(route('cart')); ?>" class="flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-b-10">
                Check Out
            </a>
        </div>
    </div>
</div><?php /**PATH /media/rahman/DATA D1/Programming/laravel/kebab-landing-page/resources/views/component/cart.blade.php ENDPATH**/ ?>