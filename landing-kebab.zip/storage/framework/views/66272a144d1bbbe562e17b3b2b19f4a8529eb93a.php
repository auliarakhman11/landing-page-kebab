<?php $__env->startSection('content'); ?>

<!-- Slider -->
<br><br><br><br>
<div class="row justify-content-center">
	<?php if(!empty($insta)): ?>
	<div class="col-12 col-md-5">
		<section class="bg0  p-b-20 ">
			
			<div class="container">
				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<?php
							$i=1;
						?>
				
						<?php $__currentLoopData = $insta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($ins->media_url && $ins->media_type == 'IMAGE'): ?>
					  <div class="carousel-item <?php echo e($i==1 ? 'active' : ''); ?>">
						<img class="d-block w-100" src="<?php echo e($ins->media_url); ?>" alt="First slide">
						
					  </div>
					  <?php
						$i++;
						?>
					<?php endif; ?>
		
					<?php if($i >= 6): ?>
						<?php
							break;
						?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon rounded" aria-hidden="true" style="background-color: #222222;"></span>
						<span class="sr-only">Previous</span>
					  </a>
					  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
						<span  class="carousel-control-next-icon rounded" aria-hidden="true" style="background-color: #222222;"></span>
						<span class="sr-only">Next</span>
					  </a>
				  </div>
			</div>
			   
				
			
			
		</section>
	</div>
	<?php endif; ?>

	<div class="col-12 col-md-5">
		<section>
			<div class="container">
				<h3 class="ltext-108 cl2 hov-cl1 trans-04"><u>Youtube</u></h3>
					<div class="row">
		
					
						<?php if($youtube): ?>
							<?php $__currentLoopData = $youtube; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($y->id->kind == "youtube#video"): ?>
								<div class="col-12 col-md-6 mt-2">
								<div class="embed-responsive embed-responsive-16by9">
									<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($y->id->videoId); ?>?rel=0" allowfullscreen></iframe>
								</div>
								</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
					
		
				</div>
			</div>   
		</section>
	</div>

	<div class="col-12 col-md-7">
		<section class="bg0 p-t-30 p-b-60">
			<div class="container">
				<h3 class="ltext-108 cl2 hov-cl1 trans-04"><u>Berita</u></h3>
				<div class="row">
					<?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-8 col-lg-9 p-b-80">
						<div class="p-r-45 p-r-0-lg">
							<!-- item blog -->
							<div class="p-b-63">
								<a href="#" class="hov-img0 how-pos5-parent">
									<img src="https://admin.kebabyasmin.com/<?php echo e($b->foto); ?>" alt="IMG-BLOG">
	
									<div class="flex-col-c-m size-123 bg9 how-pos5">
										<span class="ltext-107 cl2 txt-center">
											<?php echo e(date("d", strtotime($b->created_at))); ?>

										</span>
	
										<span class="stext-109 cl3 txt-center">
											<?php echo e(date("M Y", strtotime($b->created_at))); ?>

										</span>
									</div>
								</a>
	
								<div class="p-t-32">
									<h4 class="p-b-15">
										<a href="#" class="ltext-90 cl2 hov-cl1 trans-04">
											<?php echo e($b->caption); ?>

										</a>
									</h4>
	
									<p class="stext-90 cl6">
										<?php echo e($b->content); ?>

									</p>
	
									
	
								</div>
							</div>
							
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
	
					
				</div>
			</div>
		</section>
	</div>
</div>




	
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
            $('.carousel').carousel({
                interval: 4000
                })


        });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\kebab-landing-page\resources\views/page/home.blade.php ENDPATH**/ ?>