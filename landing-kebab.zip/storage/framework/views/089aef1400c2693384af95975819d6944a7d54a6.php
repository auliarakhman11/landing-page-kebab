<div class="header-cart-content flex-w js-pscroll">
    <ul class="header-cart-wrapitem w-full">
        <?php
            $tot = 0;
        ?>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="header-cart-item flex-w flex-t m-b-12">
            <div class="header-cart-item-img">
                <img src="https://admin.kebabyasmin.id/<?php echo e($c->options->foto); ?>" alt="IMG">
            </div>

            <div class="header-cart-item-txt p-t-8">
                <a href="#" class="header-cart-item-name hov-cl1 trans-04">
                    <?php echo e($c->qty > 1 ? $c->qty : ''); ?>  <?php echo e($c->name); ?> <?php echo e($c->options->saos ? '('.$c->options->nm_saos.')' : ''); ?>

                    <br>
                    
                </a>
                <?php
                    $harga_tambahan = 0;
                ?>
                <?php if($c->options->dt_varian): ?>
                    <?php $__currentLoopData = $c->options->dt_varian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="header-cart-item-info">
                        <?php echo e($c->qty > 1 ? $c->qty : ''); ?> <?php echo e($dtv['nm_varian']); ?> 
                    </span>
                    <?php
                        $harga_tambahan += $c->qty * $dtv['harga'];
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <span class="header-cart-item-info">
                    <i>
                    <?php echo e($c->options->ket ? '* '.$c->options->ket : ''); ?>

                    </i>
                </span>
                    
                

                <span class="header-cart-item-info">
                   <b>Rp. <?php echo e(number_format($c->qty * $c->price + $harga_tambahan,0)); ?></b>
                </span>

                <?php
                    $tot += $c->qty * $c->price + $harga_tambahan;
                ?>
                
                
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </ul>
    
    <div class="w-full">
        <div class="header-cart-total w-full p-tb-40">
            Total: Rp.<?php echo e(number_format($tot,0)); ?>

        </div>

        <div class="header-cart-buttons flex-w w-full">
            

            <a href="<?php echo e(route('cart')); ?>" class="flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-b-10">
                Check Out
            </a>
        </div>
    </div>
</div><?php /**PATH /home/u1644550/landing-kebab/resources/views/component/cart.blade.php ENDPATH**/ ?>