<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
  <div class="blog-details-post-thumbnail" style="background-image: url('<?php echo e(asset('img')); ?>/bg-kebab-yasmin.png')">
    <div class="container">
      
    </div>
  </div>
  <div class="product-description pb-3">
    <!-- Product Title & Meta Data-->
    <div class="product-title-meta-data bg-white mb-3 py-3 dir-rtl">
      <div class="container">
        <h5 class="post-title">Kebab Yasmin</h5><a class="post-catagory mb-3 d-block" href="#">Surganya Ngebab!</a>
        
      </div>
    </div>
    <div class="post-content bg-white py-3 mb-3 dir-rtl">
      <div class="container">
        
        <h6>Sekilas Tentang Kebab Yasmin</h6>
        <p>Kebab Yasmin Adalah Salah Satu Kebab Yang Berasal Dari Kota Banjarmasin, Berdiri Sejak Tahun 2012, Outlet Kebab Yasmin Sudah Tersebar Diwilayah Profinsi Kalimantan Selatan Seperti Di Banjarmasin, Banjarbaru, Martapura, Rantau, Tanjung Dan InsyaAllah Akan Membuka Dikota-Kota Lain</p>
        
      </div>
    </div>
    <!-- All Comments-->
    <div class="rating-and-review-wrapper bg-white py-3 mb-3 dir-rtl">
      <div class="container">
        <h6>Info Kemitraan</h6>
        <div class="rating-review-content">
          <ul class="ps-0">
            <li class="single-user-review d-flex">
              <div class="user-thumbnail mt-0"><img src="<?php echo e(asset('img')); ?>/whatsapp.png" alt="Whatsapp"></div>
              <div class="rating-comment">
                <p class="comment mb-0"><a href="https://wa.me/+6285654858718" target="_blank" style="text-decoration: none;">+62 856-5485-8718</a></p><span class="name-date">Syarif</span>
              </div>
            </li>
            
          </ul>
        </div>
      </div>
    </div>
    <!-- Comment Form-->
    

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
            $('.carousel').carousel({
                interval: 3000
                })

            

        });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\landing-kebab\resources\views/page/about.blade.php ENDPATH**/ ?>