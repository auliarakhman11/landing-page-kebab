<div class="footer-nav-area" id="footerNav">
    <div class="suha-footer-nav">
      <ul class="h-100 d-flex align-items-center justify-content-between ps-0 d-flex rtl-flex-d-row-r">

        <li><a href="{{ route('outlet') }}"><i class="ti ti-building-store"></i>Outlet</a></li>
        <li><a href="{{ route('home') }}"><i class="ti ti-home"></i>Home</a></li>
        <li><a href="{{ route('about') }}"><i class="ti ti-info-hexagon"></i>About Us</a></li>

        {{-- <li><a href="cart.html"><i class="ti ti-basket"></i>Cart</a></li>
        <li><a href="settings.html"><i class="ti ti-settings"></i>Settings</a></li>
        <li><a href="pages.html"><i class="ti ti-heart"></i>Pages</a></li> --}}
      </ul>
    </div>
</div>