<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-center d-flex rtl-flex-d-row-r">
      <!-- Logo Wrapper -->
      <div class="logo-wrapper"><a href="{{ route('home') }}"><img id="logo_web" src="{{ asset('img') }}/kebab-yasmin.png" alt="" style="height: 55px;"></a></div>
      {{-- <div class="navbar-logo-container d-flex align-items-center">
        <!-- Cart Icon -->
        <div class="cart-icon-wrap"><a href="cart.html"><i class="ti ti-basket-bolt"></i><span>13</span></a></div>
        <!-- User Profile Icon -->
        <div class="user-profile-icon ms-2"><a href="profile.html"><img src="{{asset('suha')}}/img/bg-img/9.jpg" alt=""></a></div>
        <!-- Navbar Toggler -->
        <div class="suha-navbar-toggler ms-2" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas">
          <div><span></span><span></span><span></span></div>
        </div>
      </div> --}}
    </div>
  </div>