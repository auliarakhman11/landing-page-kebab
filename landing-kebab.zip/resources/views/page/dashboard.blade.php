@extends('template.admin')
@section('admincontent')
<section class="bg0 p-t-23 p-b-130 mt-5">
    <div class="container">
        <div class="p-b-10">
            <h3 class="ltext-103 cl5">
                Dashboard
            </h3>
        </div>

        <div class="card">
            <div class="alert alert-success" role="alert">
                This is a success alert—check it out!
              </div>
            <div class="card-header">
                <h5>Dashboadr</h5>
            </div>
            <div class="card-body">
                <p>test</p>
            </div>
        </div>
    </div>
</section>



@endsection